#!/bin/bash

sh /usr/local/stream/processing_srm_order.sh


sh /usr/local/stream/material_price_trend.sh


sh /usr/local/stream/member_complaint.sh


sh /usr/local/stream/member_received_complaint.sh


sh /usr/local/stream/category_material.sh


sh /usr/local/stream/contract_material_price_trend.sh

